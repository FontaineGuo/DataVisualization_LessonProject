# pyecharts 体验网站

本网站只是用于展示使用 pyecharts 生成的图的效果，网站是用 Flask+pyecharts 写的，并部署在 Heroku

![image](https://user-images.githubusercontent.com/19553554/34214999-07cb1f6e-e5df-11e7-97c6-101aa969cce2.png)
