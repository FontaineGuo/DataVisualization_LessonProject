!function(){
  var d3 = {version: "3.5.0"}; // semver
