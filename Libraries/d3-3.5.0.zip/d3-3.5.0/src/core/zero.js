function d3_zero() {
  return 0;
}
